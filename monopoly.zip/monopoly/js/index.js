$(document).ready(function() {
    $("#start").click(function() {
        document.location.href = "login.html";
    });
});