<?php
    final class ResponseStatusCode
    {
        static int $OK           = 200;
        static int $LOGINFAILED  = 406;
        static int $NAMETAKEN    = 409;
        static int $ERROR        = 500;
    }
?>